
var config = {
    canvas_width: 1280,
    canvas_height: 800,
    canvas_id: "game_area", // Specifica il div contenitore
    background_color: 0x0000FF,
    debug_mode: true,
    gravity_value: 200
};

PP.game.create(config);
